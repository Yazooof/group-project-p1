package com.project.Study;


import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.json.*;


import com.project.fileIO.ReadingsXMLHandler;

/**
 * @author Andy
 * 
 * Main driver for the site readings program
 *
 */
public class ReadingsDriver {

	public static void main(String[] args) {
		
		// Give user instructions
		System.out.println("Data Collection Software\n\n"
				+ "Available commands:\n"
				+ "add <filename>: add all readings in <filename> (e.g. add input.JSON)\n"
				+ "write <filename>: write all recorded readings to <filename>\n"
				+ "start <site_id>: begin data collection at site <site_id> (e.g. start 347jd)\n"
				+ "end <site_id>: end data collection at site <site_id>\n"
				+ "show <site_id>: show all recorded data for site <site_id>\n"
				+ "exit: exit the program\n");
		
		// Map that will hold sites associated to their ids
		HashMap<String,Site> sites = new HashMap<String,Site>();
		
		// Simple loop to keep asking user for input
		Scanner sc = new Scanner(System.in);
		while(sc.hasNext()) {
			// Look at the user's first word to determine our next action
			String input = sc.nextLine().trim();
			String[] tokens = input.split("\\s+");
			
			if(tokens[0].equals("exit")) {
				break;
			}
			
			// If we didn't break, user used a command, this means we expect a second word in the input
			if(tokens.length != 2){
				System.out.println("Missing argument!");
				continue;
			}
			
			// Parse first word as one of the other five commands
			
			// Read a given input JSON file
			if(tokens[0].equals("add")) {
				String file = tokens[1];
				ArrayList<Reading> readings = null;
                                if(file.endsWith(".json") || file.endsWith("JSON")) {
                                    // Call auxiliary that does all the reading and parsing
                                    readings = readJSON(file);
                                } else if(file.endsWith(".xml") || file.endsWith("XML")) {
                                    // Call auxiliary that does all the reading and parsing
                                    readings = readXML(file);
                                }
				
				// If there are no readings, nothing left to do
				if(readings == null) {
					continue;
				}
				
				// Process all readings, only adding if collecting is enabled
				// for their associated site
				for(Reading r : readings) {
					
					// Check if site is collecting
					String site_id = r.getSite_id();
					
					// Skip if so
					if(!sites.containsKey(site_id) || !sites.get(site_id).isCollecting()) {
						System.out.println(String.format("Skipping site %s, which is not collecting.", site_id));
						continue;
					}
					
					// Else, add to that site's list of readings
					sites.get(site_id).addReading(r);
					System.out.println(String.format("Added reading to site %s.", site_id));
				}
			
			// Write all readings to a file
			} else if(tokens[0].equals("write")) {
				String file = tokens[1];
				
				// Collect all readings we have so far
				ArrayList<Reading> combined = new ArrayList<Reading>();
				for(Site site : sites.values())
					combined.addAll(site.getReadings());

				// Call our auxiliary method for writing JSONs
				writeJSON(combined, file);
				
			// Start collecting on a given site
			} else if(tokens[0].equals("start")) {
				String site_id = tokens[1];
				
				// Check if we've created this site before, if not, create it
				if(!sites.containsKey(site_id))
					sites.put(site_id, new Site(site_id));
				
				// Mark the site associated to this id as collecting
				sites.get(site_id).setCollecting(true);
				
			// Stop collecting on a given site
			} else if(tokens[0].equals("end")) {
				String site_id = tokens[1];
				
				// Check if we've created this site before, if not, we're done
				if(!sites.containsKey(site_id)) {
					continue;
				// Else, mark the site associated to this id as not collecting
				} else {
					sites.get(site_id).setCollecting(false);
				}
				
			} else if(tokens[0].equals("show")) {
				String site_id = tokens[1];
				
				// Check if we've created this site, if not, error and continue
				if(!sites.containsKey(site_id)) {
					System.out.println("Site has no associated readings.");
				// Else, print all readings in its ArrayList
				} else {
					for(Reading r : sites.get(site_id).getReadings())
						System.out.println(r.toString());
				}
				
			} else {
				System.out.println("Command not recognized.");
			}
		}
		
		sc.close();
		
		ArrayList<Reading> readings = readJSON("input.json");
		writeJSON(readings, "out.json");
	}
	
	/**
	 * Auxiliary function for writing readings to a JSON file
	 */
	private static void writeJSON(ArrayList<Reading> readings, String path) {
		// JSONArray that will hold all readings
		JSONArray combined = new JSONArray();
		
		// Add all readings to a JSONObject, and then to the array
		for(Reading r : readings) {
			JSONObject curr = new JSONObject(r);
			combined.put(curr);
		}
		
		// Add array to a final JSONObject
		JSONObject top = new JSONObject();
		top.put("site_readings", combined);
		
		// Finally, write to file
		try(FileWriter writer = new FileWriter(path)) {
			top.write(writer);
		} catch (IOException e) {
			System.out.println("Could not open file for IO!");
			e.printStackTrace();
		}
	}
	
	/**
	 * Auxiliary function for opening and reading JSON file
	 */
	private static ArrayList<Reading> readJSON(String path) {
		JSONObject in = null;
		// Create reader, which can be used to construct a JSON parser
		try(FileReader reader = new FileReader(path)) {
			JSONTokener tok = new JSONTokener(reader);
			in = new JSONObject(tok);
		} catch (Exception e) {
			System.out.println("Could not open file for IO! ");
			return null;
		}
		
		// Check for badly formed input JSON
		if(in.isNull("site_readings")) {
			System.out.println("JSON file has no site_readings field!");
			return null;
		}
			
		// If file has been read, and contains readings, begin splitting into readings
		ArrayList<Reading> ret = new ArrayList<Reading>();
		JSONArray json_readings = in.getJSONArray("site_readings");
		
		for(int i = 0; i != json_readings.length(); ++i)
		{
			JSONObject json_curr = json_readings.getJSONObject(i);
			
			// Confirm that reading has the required fields
			if(!json_curr.has("reading_type") ||
				!json_curr.has("site_id") ||
				!json_curr.has("reading_id") ||
				!json_curr.has("reading_value") ||
				!json_curr.has("reading_date")) {
				System.out.println("Skipping badly formed reading: missing field");
				continue;
			}
			
			// Confirm supported reading type
			String type = json_curr.getString("reading_type");
			if(!type.equals("humidity") && !type.equals("temp") && !type.equals("bar_press") && !type.equals("particulate")) {
				System.out.println("Skipping badly formed reading: reading type is not supported");
				continue;
			}
			
			// Construct reading based on the JSON fields
			Reading curr = new Reading(type,
					json_curr.getString("site_id"),
					json_curr.getString("reading_id"),
					json_curr.getDouble("reading_value"),
					json_curr.getLong("reading_date"));

			ret.add(curr);
		}
		
		return ret;
	}
        
        /**
	 * Auxiliary function for opening and reading JSON file
	 */
	private static ArrayList<Reading> readXML(String path) {
            ArrayList<Reading> readings = null;
            SAXParserFactory saxParserFactory = SAXParserFactory.newInstance();
            try {
                SAXParser saxParser = saxParserFactory.newSAXParser();
                ReadingsXMLHandler handler = new ReadingsXMLHandler();
                saxParser.parse(new File(path), handler);
                //Get Readings list
                readings = handler.getReadings();
            } catch (Exception e) {
                e.printStackTrace();
            }
            return readings;
	}
}