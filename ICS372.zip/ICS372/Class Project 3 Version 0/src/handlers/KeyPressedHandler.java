/**
 * 
 * @author Brahma Dathan
 * 
 *         Redistribution and use with or without modification, are permitted
 *         provided that the following conditions are met: the use is for
 *         academic purpose only - Redistributions of source code must retain
 *         the above copyright notice, this list of conditions and the following
 *         disclaimer. - The name of Brahma Dathan may not be used to
 *         endorse or promote products derived from this software without
 *         specific prior written permission.
 *
 *         The author does not make any claims regarding the correctness of the
 *         code in this module and are not responsible for any loss or damage
 */
package handlers;

import events.BackspaceKeyEvent;
import events.EnterKeyEvent;
import events.EscapeKeyEvent;
import javafx.event.EventHandler;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import states.DrawingContext;

/**
 * Handles Enter, Escape, and Backspace key pushes
 * 
 * @author Brahma Dathan
 *
 */
public class KeyPressedHandler implements EventHandler<KeyEvent> {
    @Override
    public void handle(KeyEvent keyPressed) {
        if (keyPressed.getCode().equals(KeyCode.BACK_SPACE)) {
            DrawingContext.instance().handleEvent(BackspaceKeyEvent.instance());
        } else if (keyPressed.getCode().equals(KeyCode.ESCAPE)) {
            DrawingContext.instance().handleEvent(EscapeKeyEvent.instance());
        } else if (keyPressed.getCode().equals(KeyCode.ENTER)) {
            DrawingContext.instance().handleEvent(EnterKeyEvent.instance());
        }
    }

}
