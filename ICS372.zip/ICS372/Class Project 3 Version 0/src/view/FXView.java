/**
 *
 *            Redistribution and use with or without modification, are permitted
 *            provided that the following conditions are met:
 *
 *            - the use is for academic purpose only - Redistributions of source
 *            code must retain the above copyright notice, this list of
 *            conditions and the following disclaimer. - The name of Brahma Dathan
 *            may not be used to endorse or promote
 *            products derived from this software without specific prior written
 *            permission.
 *
 *            The author does not make any claims regarding the correctness of
 *            the code in this module and are not responsible for any loss or
 *            damage resulting from its use.
 */
package view;

import java.util.Observable;
import java.util.Observer;

import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;

/**
 * The view for JavaFX. This is a display-only view.
 * 
 * @author Brahma Dathan
 *
 */
public class FXView extends Stage implements Observer, EventHandler<WindowEvent> {
    private FXPanel drawingPanel;

    /**
     * Creates the view with just a panel.
     */
    public FXView() {
        drawingPanel = new FXPanel();
        Scene scene = new Scene(drawingPanel);
        setScene(scene);
        setTitle("FX View ");
        this.setOnCloseRequest(this);
        show();

    }

    /**
     * Catches updates from the model
     * 
     * @param model
     *            the source: it is the model
     * @param dummy
     *            : not used
     */
    @Override
    public void update(Observable model, Object dummy) {
        drawingPanel.draw();
    }

    @Override
    public void handle(WindowEvent event) {

    }
}
