/**
 *
 *            Redistribution and use with or without modification, are permitted
 *            provided that the following conditions are met:
 *
 *            - the use is for academic purpose only - Redistributions of source
 *            code must retain the above copyright notice, this list of
 *            conditions and the following disclaimer. - The name of Brahma Dathan
 *            may not be used to endorse or promote
 *            products derived from this software without specific prior written
 *            permission.
 *
 *            The author does not make any claims regarding the correctness of
 *            the code in this module and are not responsible for any loss or
 *            damage resulting from its use.
 */
package view;

/**
 * Implements the LogicalView interface. This displays all the shapes.
 */
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
import java.util.Iterator;

import model.Model;
import shapes.Shape;

public class LogicalViewImpl implements LogicalView {
    private static LogicalViewImpl view;
    private PropertyChangeSupport propertyChangeSupport = new PropertyChangeSupport(this);

    /**
     * Private constructor for the singleton pattern
     */
    private LogicalViewImpl() {
        Model.instance().addView(this);
    }

    /**
     * Returns the only instance
     * 
     * @return the only instance
     */
    public static LogicalViewImpl instance() {
        if (view == null) {
            view = new LogicalViewImpl();
        }
        return view;
    }

    @Override
    public void addPhysicalView(PhysicalView physicalView) {
        propertyChangeSupport.addPropertyChangeListener(physicalView);
    }

    @Override
    public void removePhysicalView(PhysicalView physicalView) {
        propertyChangeSupport.removePropertyChangeListener(physicalView);
    }

    @Override
    public void propertyChange(PropertyChangeEvent event) {
        for (PropertyChangeListener listener : propertyChangeSupport.getPropertyChangeListeners()) {
            PhysicalView view = (PhysicalView) listener;
            view.propertyChange(null);
        }
    }

    @Override
    public void draw(PhysicalView physicalView) {
        Iterator<Shape> items = Model.instance().getShapes();
        while (items.hasNext()) {
            Shape item = items.next();
            item.render(physicalView.getRenderer());
        }
    }

    @Override
    public void setCursorToDefault() {
        for (PropertyChangeListener listener : propertyChangeSupport.getPropertyChangeListeners()) {
            ((PhysicalView) listener).setCursorToDefault();
        }
    }

    @Override
    public void setsCursorToDrawing() {
        for (PropertyChangeListener listener : propertyChangeSupport.getPropertyChangeListeners()) {
            ((PhysicalView) listener).setsCursorToDrawing();
        }
    }

    @Override
    public void update() {
        propertyChangeSupport.firePropertyChange(null, null, null);
    }

}
