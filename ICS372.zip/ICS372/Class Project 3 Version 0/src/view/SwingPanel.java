/**
 *
 *            Redistribution and use with or without modification, are permitted
 *            provided that the following conditions are met:
 *
 *            - the use is for academic purpose only - Redistributions of source
 *            code must retain the above copyright notice, this list of
 *            conditions and the following disclaimer. - The name of Brahma Dathan
 *            may not be used to endorse or promote
 *            products derived from this software without specific prior written
 *            permission.
 *
 *            The author does not make any claims regarding the correctness of
 *            the code in this module and are not responsible for any loss or
 *            damage resulting from its use.
 */
package view;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.beans.PropertyChangeEvent;

import javax.swing.JPanel;

import model.Model;
import renderer.Renderer;
import renderer.SwingRenderer;

/**
 * Display-only panel using the Swing technology
 * 
 * @author Brahma Dathan
 *
 */
public class SwingPanel extends JPanel implements PhysicalView {

    /**
     * The panel where drawing occurs
     *
     */
    public SwingPanel(Model model) {
        LogicalViewImpl.instance().addPhysicalView(this);
        this.setPreferredSize(new Dimension(600, 400));
        repaint();
    }

    /**
     * Paints the panel
     * 
     * @param graphics
     *            the Graphics object
     */
    @Override
    public void paintComponent(Graphics graphics) {
        super.paintComponent(graphics);
        (SwingRenderer.getInstance()).setGraphics(graphics);
        graphics.setColor(Color.BLUE);
        LogicalViewImpl.instance().draw(this);
    }

    @Override
    public void propertyChange(PropertyChangeEvent evt) {
        repaint();
    }

    @Override
    public Renderer getRenderer() {
        return SwingRenderer.getInstance();
    }

    @Override
    public void setCursorToDefault() {
    }

    @Override
    public void setsCursorToDrawing() {
    }

}
