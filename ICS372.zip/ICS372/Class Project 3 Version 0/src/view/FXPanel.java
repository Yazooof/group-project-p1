/**
 *
 *            Redistribution and use with or without modification, are permitted
 *            provided that the following conditions are met:
 *
 *            - the use is for academic purpose only - Redistributions of source
 *            code must retain the above copyright notice, this list of
 *            conditions and the following disclaimer. - The name of Brahma Dathan
 *            may not be used to endorse or promote
 *            products derived from this software without specific prior written
 *            permission.
 *
 *            The author does not make any claims regarding the correctness of
 *            the code in this module and are not responsible for any loss or
 *            damage resulting from its use.
 */
package view;

import java.beans.PropertyChangeEvent;

import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import renderer.FXRenderer;
import renderer.Renderer;

/**
 * The area where the drawing occurs.
 * 
 * @author Brahma Dathan
 *
 */
public class FXPanel extends Pane implements PhysicalView {
    private Canvas canvas;

    /**
     * The panel where drawing occurs
     *
     */
    public FXPanel() {
        LogicalViewImpl.instance().addPhysicalView(this);
        canvas = new Canvas(600, 600);
        getChildren().add(canvas);
        draw();
    }

    /**
     * Paints the panel
     * 
     * @param graphics
     *            the Graphics object
     */
    public void draw() {
        GraphicsContext graphicsContext = canvas.getGraphicsContext2D();
        (FXRenderer.getInstance()).setGraphics(graphicsContext);
        graphicsContext.setFill(Color.WHITE);
        graphicsContext.fillRect(0, 0, canvas.getWidth(), canvas.getHeight());
        graphicsContext.setStroke(Color.GREEN);
        graphicsContext.strokeRect(1, 1, canvas.getWidth() - 1, canvas.getHeight() - 1);
        LogicalViewImpl.instance().draw(this);
    }

    @Override
    public void propertyChange(PropertyChangeEvent evt) {
        draw();
    }

    @Override
    public Renderer getRenderer() {
        FXRenderer.getInstance().setGraphics(canvas.getGraphicsContext2D());
        return FXRenderer.getInstance();
    }

    @Override
    public void setCursorToDefault() {
    }

    @Override
    public void setsCursorToDrawing() {
    }

}
