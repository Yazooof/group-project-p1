/**
 * 
 * @author Brahma Dathan
 * 
 *         Redistribution and use with or without modification, are permitted
 *         provided that the following conditions are met: the use is for
 *         academic purpose only - Redistributions of source code must retain
 *         the above copyright notice, this list of conditions and the following
 *         disclaimer. - The name of Brahma Dathan may not be used to
 *         endorse or promote products derived from this software without
 *         specific prior written permission.
 *
 *         The author does not make any claims regarding the correctness of the
 *         code in this module and are not responsible for any loss or damage
 *         resulting from its use.
 */
/**
 * A panel of buttons for drawing operations
 * 
 * @author Brahma Dathan
 *
 */
package drawingtool;

import buttons.LabelButton;
import buttons.LineButton;
import buttons.OpenButton;
import buttons.PolygonButton;
import buttons.SaveButton;
import javafx.geometry.Insets;
import javafx.scene.control.Button;
import javafx.scene.layout.VBox;

public class ButtonPanel extends VBox {
    private Button lineButton;
    private Button polygonButton;
    private Button labelButton;
    private Button saveButton;
    private Button openButton;

    /**
     * Assembles the panel
     */
    public ButtonPanel() {
        polygonButton = new PolygonButton();
        lineButton = new LineButton();
        labelButton = new LabelButton();
        saveButton = new SaveButton();
        openButton = new OpenButton();
        setPrefHeight(polygonButton.getHeight() * 12);
        setSpacing(5);
        this.getChildren().add(lineButton);
        this.getChildren().add(polygonButton);
        this.getChildren().add(labelButton);
        this.getChildren().add(saveButton);
        this.getChildren().add(openButton);
        setPadding(new Insets(10, 10, 10, 10));
    }
}
