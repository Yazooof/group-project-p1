/**
 *
 *            Redistribution and use with or without modification, are permitted
 *            provided that the following conditions are met:
 *
 *            - the use is for academic purpose only - Redistributions of source
 *            code must retain the above copyright notice, this list of
 *            conditions and the following disclaimer. - The name of Brahma Dathan
 *            may not be used to endorse or promote
 *            products derived from this software without specific prior written
 *            permission.
 *
 *            The author does not make any claims regarding the correctness of
 *            the code in this module and are not responsible for any loss or
 *            damage resulting from its use.
 */
package states;

import events.BackspaceKeyEvent;
import events.CharacterKeyEvent;
import events.CreateLabelEvent;
import events.CreateLineEvent;
import events.CreatePolygonEvent;
import events.EnterKeyEvent;
import events.EscapeKeyEvent;
import events.MouseClickEvent;
import events.MouseEnterEvent;
import events.MouseExitEvent;
import events.OpenRequestEvent;
import events.SaveRequestEvent;
import model.Model;
import view.LogicalViewImpl;

/**
 * The common drawing state
 *
 * @author Brahma Dathan
 *
 */
public abstract class DrawingState {
    /**
     * This method abandons any construction that be occurring.
     *
     */
    public abstract void abandon();

    /**
     * What to do when entering the state
     */
    public void enter() {
    }

    /**
     * What to do while leaving state
     */
    public void leave() {
    }

    /**
     * Handles the request to create a label.
     *
     * @param event
     *            - the event that represents label creation
     */
    public void handleEvent(CreateLabelEvent event) {
    }

    /**
     * Handles the request to create a line.
     *
     * @param event
     *            - the event that represents line creation
     */
    public void handleEvent(CreateLineEvent event) {
    }

    /**
     * Handles the request to create a polygon.
     *
     * @param event
     *            - the event that represents line creation
     */
    public void handleEvent(CreatePolygonEvent event) {
    }

    /**
     * Handles the request to open a file.
     *
     * @param event
     *            - the event that represents open request
     */
    public void handleEvent(OpenRequestEvent event) {
        Model.instance().retrieve(event.getFile());
    }

    /**
     * Handles the request to save a file.
     *
     * @param event
     *            - the event that represents save request
     */
    public void handleEvent(SaveRequestEvent event) {
        Model.instance().save(event.getFile());
    }

    /**
     * Handles a mouse click.
     *
     * @param event
     *            - the event that represents a mouse click
     */
    public void handleEvent(MouseClickEvent e) {
    }

    /**
     * Handles escape key
     *
     * @param event
     *            - the event that represents escape key press
     */
    public void handleEvent(EscapeKeyEvent e) {
        abandon();
    }

    /**
     * Handles enter key
     *
     * @param event
     *            - the event that represents enter key press
     */
    public void handleEvent(EnterKeyEvent e) {
    }

    /**
     * Handles the input of a character
     *
     * @param event
     *            - the event that represents a character input
     */
    public void handleEvent(CharacterKeyEvent event) {
    }

    /**
     * Handles the pressing of the BackSpace key
     *
     * @param event
     *            - the event that represents BackSpace key pressing
     */
    public void handleEvent(BackspaceKeyEvent event) {
    }

    /**
     * Handles the entry of the mouse to the drawing panel
     * 
     * @param event
     */
    public void handleEvent(MouseEnterEvent event) {
        LogicalViewImpl.instance().setsCursorToDrawing();
    }

    /**
     * Handles the exit of the mouse from the drawing panel
     * 
     * @param event
     */
    public void handleEvent(MouseExitEvent event) {
        LogicalViewImpl.instance().setCursorToDefault();
    }
}
