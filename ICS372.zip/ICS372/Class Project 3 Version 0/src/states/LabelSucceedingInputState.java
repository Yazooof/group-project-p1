/**
 *
 *            Redistribution and use with or without modification, are permitted
 *            provided that the following conditions are met:
 *
 *            - the use is for academic purpose only - Redistributions of source
 *            code must retain the above copyright notice, this list of
 *            conditions and the following disclaimer. - The name of Brahma Dathan
 *            may not be used to endorse or promote
 *            products derived from this software without specific prior written
 *            permission.
 *
 *            The author does not make any claims regarding the correctness of
 *            the code in this module and are not responsible for any loss or
 *            damage resulting from its use.
 */

package states;

import events.BackspaceKeyEvent;
import events.CharacterKeyEvent;
import events.EnterKeyEvent;
import events.MouseClickEvent;
import javafx.geometry.Point2D;
import model.Model;
import shapes.Label;
import view.LogicalViewImpl;

/**
 *
 * @author Brahma Dathan
 *
 */
public class LabelSucceedingInputState extends DrawingState {
    private static LabelSucceedingInputState instance;

    /**
     * Private constructor to make the class a singleton
     */
    private LabelSucceedingInputState() {
    }

    /**
     * Returns the singleton object
     *
     * @return - the only instance of the class
     */
    public static LabelSucceedingInputState instance() {
        if (instance == null) {
            instance = new LabelSucceedingInputState();
        }
        return instance;
    }

    @Override
    public void abandon() {
        Model.instance().removeShape(DrawingContext.instance().getShape());
        DrawingContext.instance().changeCurrentState(QuiescentState.instance());
    }

    @Override
    public void handleEvent(CharacterKeyEvent event) {
        ((Label) DrawingContext.instance().getShape()).removeCharacter();
        ((Label) DrawingContext.instance().getShape()).addCharacter(event.getCharacter() + "|");
        LogicalViewImpl.instance().update();
    }

    @Override
    public void handleEvent(BackspaceKeyEvent event) {
        ((Label) DrawingContext.instance().getShape()).removeCharacter();
        ((Label) DrawingContext.instance().getShape()).removeCharacter();
        ((Label) DrawingContext.instance().getShape()).addCharacter("|");
        LogicalViewImpl.instance().update();
    }

    @Override
    public void handleEvent(MouseClickEvent event) {
        ((Label) DrawingContext.instance().getShape()).removeCharacter();
        DrawingContext.instance().setShape(new Label(new Point2D(event.getX(), event.getY())));
        Model.instance().addShape(DrawingContext.instance().getShape());
        ((Label) DrawingContext.instance().getShape()).addCharacter("|");
    }

    @Override
    public void handleEvent(EnterKeyEvent event) {
        ((Label) DrawingContext.instance().getShape()).removeCharacter();
        LogicalViewImpl.instance().update();
        DrawingContext.instance().changeCurrentState(QuiescentState.instance());
    }

}
