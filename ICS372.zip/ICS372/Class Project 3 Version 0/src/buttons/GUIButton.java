/**
 * 
 * @author Brahma Dathan
 * 
 *         Redistribution and use with or without modification, are permitted
 *         provided that the following conditions are met: the use is for
 *         academic purpose only - Redistributions of source code must retain
 *         the above copyright notice, this list of conditions and the following
 *         disclaimer. - The name of Brahma Dathan may not be used to
 *         endorse or promote products derived from this software without
 *         specific prior written permission.
 *
 *         The author does not make any claims regarding the correctness of the
 *         code in this module and are not responsible for any loss or damage
 *         resulting from its use.
 */
/**
 * The button for drawing a label
 * 
 * @author Brahma Dathan
 *
 */
package buttons;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.control.Button;

/**
 * 
 * @author Brahma Dathan
 * 
 *         Redistribution and use with or without modification, are permitted
 *         provided that the following conditions are met: the use is for
 *         academic purpose only - Redistributions of source code must retain
 *         the above copyright notice, this list of conditions and the following
 *         disclaimer. - The name of Brahma Dathan may not be used to
 *         endorse or promote products derived from this software without
 *         specific prior written permission.
 *
 *         The author does not make any claims regarding the correctness of the
 *         code in this module and are not responsible for any loss or damage
 *         resulting from its use.
 */

/**
 * The abstract GUI Button.
 *
 * @author Brahma Dathan
 *
 */
public abstract class GUIButton extends Button implements EventHandler<ActionEvent> {
    /**
     * Create the button with the proper text This superclass sets the width and
     * height for all buttons plus the padding.
     * 
     * @param string
     *            the text in the button
     */
    public GUIButton(String string) {
        super(string);
        setPrefWidth(150);
        setPrefHeight(20);
        setPadding(new Insets(10, 30, 10, 30));
        setOnAction(this);
    }

}