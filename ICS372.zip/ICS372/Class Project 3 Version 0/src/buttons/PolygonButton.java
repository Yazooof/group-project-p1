package buttons;

import events.CreatePolygonEvent;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import states.DrawingContext;

/**
 * 
 * @author Brahma Dathan
 * @Copyright (c) 2018
 * 
 *            Redistribution and use with or without modification, are permitted
 *            provided that the following conditions are met:
 *
 *            - the use is for academic purpose only - Redistributions of source
 *            code must retain the above copyright notice, this list of
 *            conditions and the following disclaimer. - Neither the name of
 *            Brahma Dathan or Sarnath Ramnath may be used to endorse or promote
 *            products derived from this software without specific prior written
 *            permission.
 *
 *            The authors do not make any claims regarding the correctness of
 *            the code in this module and are not responsible for any loss or
 *            damage resulting from its use.
 */
public class PolygonButton extends GUIButton implements EventHandler<ActionEvent> {
    /**
     * The button for drawing a polygon
     * 
     * @param string
     */
    public PolygonButton() {
        super("Polygon");
    }

    @Override
    public void handle(ActionEvent event) {
        DrawingContext.instance().handleEvent(CreatePolygonEvent.instance());
    }
}