package buttons;

import java.io.File;

import events.OpenRequestEvent;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.stage.FileChooser;
import states.DrawingContext;

/**
 * 
 * @author Brahma Dathan
 * 
 *         Redistribution and use with or without modification, are permitted
 *         provided that the following conditions are met: the use is for
 *         academic purpose only - Redistributions of source code must retain
 *         the above copyright notice, this list of conditions and the following
 *         disclaimer. - The name of Brahma Dathan may not be used to
 *         endorse or promote products derived from this software without
 *         specific prior written permission.
 *
 *         The author does not make any claims regarding the correctness of the
 *         code in this module and are not responsible for any loss or damage
 *         resulting from its use.
 */
/**
 * The button for opening a file that contains a drawing.
 * 
 * @author Brahma Dathan
 *
 */
public class OpenButton extends GUIButton implements EventHandler<ActionEvent> {
    /**
     * The constructor for opening a file that contains a drawing The button
     * handles the clicks to itself.
     * 
     */
    public OpenButton() {
        super("Open");
    }

    @Override
    public void handle(ActionEvent event) {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle("Open drawing");
        File file = fileChooser.showOpenDialog(null);
        if (file != null) {
            DrawingContext.instance().handleEvent(new OpenRequestEvent(file));
        }
    }
}