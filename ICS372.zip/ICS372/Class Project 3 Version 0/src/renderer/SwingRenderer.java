/**
 * 
 * @author Brahma Dathan
 * @Copyright (c) 2018
 
 * Redistribution and use with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *   - the use is for academic purpose only
 *   - Redistributions of source code must retain the above copyright
 *     notice, this list of conditions and the following disclaimer.
 *   - Neither the name of Brahma Dathan or Sarnath Ramnath
 *     may be used to endorse or promote products derived
 *     from this software without specific prior written permission.
 *
 * The authors do not make any claims regarding the correctness of the code in this module
 * and are not responsible for any loss or damage resulting from its use.  
 */
package renderer;

import java.awt.Color;
/**
 * 
 * @author Brahma Dathan and Sarnath Ramnath
 * @Copyright (c) 2010
 
 * Redistribution and use with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *   - the use is for academic purpose only
 *   - Redistributions of source code must retain the above copyright
 *     notice, this list of conditions and the following disclaimer.
 *   - Neither the name of Brahma Dathan or Sarnath Ramnath
 *     may be used to endorse or promote products derived
 *     from this software without specific prior written permission.
 *
 * The authors do not make any claims regarding the correctness of the code in this module
 * and are not responsible for any loss or damage resulting from its use.  
 */
import java.awt.Graphics;

/**
 * Implements the swing renderer
 * 
 * @author Brahma Dathan
 *
 */
public class SwingRenderer implements Renderer {
    private Graphics graphics;
    private static SwingRenderer swingRenderer;

    /**
     * For the singleton pattern
     */
    private SwingRenderer() {
    }

    /**
     * Returns the instance
     * 
     * @return the instance
     */
    public static SwingRenderer getInstance() {
        if (swingRenderer == null) {
            swingRenderer = new SwingRenderer();
        }
        return swingRenderer;
    }

    /**
     * The Graphics object for drawing
     * 
     * @param graphics
     *            the Graphics object
     */
    public void setGraphics(Graphics graphics) {
        this.graphics = graphics;
    }

    @Override
    public void draw(double x1, double y1, String text) {
        graphics.drawString(text, (int) x1, (int) y1);

    }

    @Override
    public void draw(double x1, double y1, double radius, double startAngle, double endAngle) {
        graphics.drawArc((int) (x1 - radius), (int) (y1 - radius), (int) (2 * radius), (int) (2 * radius),
                (int) startAngle, (int) (endAngle - startAngle));
    }

    @Override
    public void draw(double x1, double y1, double x2, double y2) {
        graphics.drawLine((int) x1, (int) y1, (int) x2, (int) y2);
    }

    @Override
    public void draw() {
    }

    @Override
    public void setColor(int red, int green, int blue) {
        graphics.setColor(new Color(red, green, blue));
    }

}