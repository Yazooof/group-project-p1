/**
 * 
 *            Redistribution and use with or without modification, are permitted
 *            provided that the following conditions are met:
 *
 *            - the use is for academic purpose only - Redistributions of source
 *            code must retain the above copyright notice, this list of
 *            conditions and the following disclaimer. - The name of Brahma Dathan 
 *            may not be used to endorse or promote
 *            products derived from this software without specific prior written
 *            permission.
 *
 *            The author does not make any claims regarding the correctness of
 *            the code in this module and are not responsible for any loss or
 *            damage resulting from its use.
 */
package events;

/**
 * Used when an undo operation is issued
 * 
 * @author Brahma Dathan
 *
 */
public class UndoRequestEvent extends DrawingEvent {
    private static UndoRequestEvent instance;

    /**
     * Constructor is private to implement the singleton pattern.
     */

    private UndoRequestEvent() {
    }

    /**
     * Static method to return the only instance of the class.
     * 
     * @return - the only instance
     */
    public static UndoRequestEvent instance() {
        if (instance == null) {
            instance = new UndoRequestEvent();
        }
        return instance;
    }
}
