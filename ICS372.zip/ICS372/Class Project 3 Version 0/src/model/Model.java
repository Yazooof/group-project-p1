/**
 * 
 *            Redistribution and use with or without modification, are permitted
 *            provided that the following conditions are met:
 *
 *            - the use is for academic purpose only - Redistributions of source
 *            code must retain the above copyright notice, this list of
 *            conditions and the following disclaimer. - The name of Brahma Dathan 
 *            may not be used to endorse or promote
 *            products derived from this software without specific prior written
 *            permission.
 *
 *            The author does not make any claims regarding the correctness of
 *            the code in this module and are not responsible for any loss or
 *            damage resulting from its use.
 */
package model;

import java.beans.PropertyChangeSupport;
import java.io.File;
/**
 * 
 * @author Brahma Dathan and Sarnath Ramnath
 * @Copyright (c) 2010
 
 * Redistribution and use with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *   - the use is for academic purpose only
 *   - Redistributions of source code must retain the above copyright
 *     notice, this list of conditions and the following disclaimer.
 *   - Neither the name of Brahma Dathan or Sarnath Ramnath
 *     may be used to endorse or promote products derived
 *     from this software without specific prior written permission.
 *
 * The authors do not make any claims regarding the correctness of the code in this module
 * and are not responsible for any loss or damage resulting from its use.  
 */
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

import shapes.Shape;
import view.LogicalView;

/**
 * The model in the MVC pattern. Stores all items organized as two lists.
 * 
 * @author Brahma Dathan
 */
public class Model {
    private PropertyChangeSupport propertyChangeSupport = new PropertyChangeSupport(this);
    private List<Shape> shapeList;
    private static Model instance;

    /**
     * Creates the the list to store the shapes. Private to implement the
     * singleton pattern.
     */
    private Model() {
        shapeList = new LinkedList<Shape>();
    }

    /**
     * Creates the model if needed and returns it.
     * 
     * @return - the only instance of the model
     */
    public static Model instance() {
        if (instance == null) {
            instance = new Model();
        }
        return instance;
    }

    /**
     * Stores a new shape
     * 
     * @param item
     *            the new shape
     */
    public void addShape(Shape item) {
        shapeList.add(item);
        updateView();
    }

    /**
     * Removes a shape
     * 
     * @param shape
     *            the shape to be removed
     */
    public void removeShape(Shape shape) {
        shapeList.remove(shape);
        updateView();
    }

    /**
     * Returns an iterator of the unselected shapes
     * 
     * @return iterator of the unselected shapes
     */
    public Iterator<Shape> getShapes() {
        return shapeList.iterator();
    }

    /**
     * Adds a logical view as a listener
     * 
     * @param view
     *            the new listener
     */
    public void addView(LogicalView view) {
        propertyChangeSupport.addPropertyChangeListener(view);
    }

    /**
     * Notifies the view
     */
    public void updateView() {
        propertyChangeSupport.firePropertyChange(null, null, null);
    }

    /**
     * Saves the shapes in the specified file
     * 
     * @param fileName
     *            file to be used for storing
     */
    public void save(File file) {
        try {
            ObjectOutputStream output = new ObjectOutputStream(new FileOutputStream(file));
            output.writeObject(shapeList);
            output.close();
        } catch (IOException ioe) {
            ioe.printStackTrace();
        }
    }

    /**
     * Retrieves the shapes in the specified file
     * 
     * @param fileName
     *            file that contains the shapes
     */
    public void retrieve(File file) {
        try {
            ObjectInputStream input = new ObjectInputStream(new FileInputStream(file));
            shapeList = (List) input.readObject();
            updateView();
            input.close();
        } catch (IOException ioe) {
            ioe.printStackTrace();
        } catch (ClassNotFoundException cnfe) {
            cnfe.printStackTrace();
        }
    }
}