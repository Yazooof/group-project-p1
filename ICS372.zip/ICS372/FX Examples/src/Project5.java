import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.Button;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.GridPane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

public class Project5 extends Application implements EventHandler<ActionEvent> {
	private Button rectangleButton = new Button("Rectangle");
	private Button circleButton = new Button("Circle");
	private Button greenButton = new Button("Green");
	private Button redButton = new Button("Red");
	private Canvas canvas = new Canvas(300, 300);
	private Color color = Color.RED;
	private int shape = RECTANGLE;
	private static final int RECTANGLE = 1;
	private static final int CIRCLE = 2;

	@Override
	public void start(Stage primaryStage) throws Exception {
		GridPane pane = new GridPane();
		pane.add(canvas, 0, 0);
		GridPane buttonPane = new GridPane();
		buttonPane.add(rectangleButton, 0, 0);
		buttonPane.add(circleButton, 1, 0);
		buttonPane.add(greenButton, 0, 1);
		buttonPane.add(redButton, 1, 1);
		pane.add(buttonPane, 0, 1);
		Scene scene = new Scene(pane);
		primaryStage.setTitle("Project 5");
		primaryStage.setScene(scene);
		rectangleButton.setOnAction(this);
		greenButton.setOnAction(this);
		circleButton.setOnAction(this);
		redButton.setOnAction(this);
		canvas.setOnMouseClicked(new EventHandler<MouseEvent>() {

			@Override
			public void handle(MouseEvent event) {
				GraphicsContext gc = canvas.getGraphicsContext2D();
				gc.setFill(color);
				if (shape == CIRCLE) {
					gc.fillOval(event.getSceneX(), event.getSceneY(), 50, 50);
				} else if (shape == RECTANGLE) {
					gc.fillRect(event.getSceneX(), event.getSceneY(), 80, 40);
				}
			}
		});
		primaryStage.show();
	}

	public static void main(String[] args) {
		Application.launch(null);
	}

	@Override
	public void handle(ActionEvent event) {
		if (event.getSource() == redButton) {
			color = Color.RED;
		} else if (event.getSource() == greenButton) {
			color = Color.GREEN;
		} else if (event.getSource() == rectangleButton) {
			shape = RECTANGLE;
		} else if (event.getSource() == circleButton) {
			shape = CIRCLE;
		}
	}

}
