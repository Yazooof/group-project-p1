import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

public class Project3 extends Application implements EventHandler<ActionEvent> {
	private Button okButton = new Button("OK");
	private Button decrementButton = new Button("Decrement");
	private TextField field = new TextField();
	private int counter = 1;
	Canvas canvas = new Canvas(100, 200);

	@Override
	public void start(Stage primaryStage) throws Exception {
		GridPane pane = new GridPane();
		pane.add(field, 0, 0);
		pane.add(okButton, 0, 1);
		pane.add(decrementButton, 0, 2);
		pane.add(canvas, 0, 3);
		Scene scene = new Scene(pane);
		primaryStage.setTitle("Project 3");
		primaryStage.setScene(scene);
		okButton.setOnAction(this);
		decrementButton.setOnAction(this);
		primaryStage.show();
	}

	public static void main(String[] args) {
		Application.launch(null);
	}

	@Override
	public void handle(ActionEvent event) {
		if (event.getSource() == okButton) {
			field.setText("Clicked " + counter + " times");
			counter++;
			GraphicsContext gc = canvas.getGraphicsContext2D();
			gc.strokeLine(20, 30, 40, 50);
			new S2();
		} else if (event.getSource() == decrementButton) {
			counter--;
			field.setText("Decremented to " + counter);
		}
	}

}
