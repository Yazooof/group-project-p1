import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

/**
 * This program helps the user speed up typing by providing the ability create
 * buttons that represent potentially large pieces of text. The user can type
 * the text and create a button for that by clicking on a button labeled create
 * button. At most 20 buttons can be created.
 * 
 * @author Brahma Dathan
 *
 *
 */
public class PA2 extends Application implements EventHandler<ActionEvent> {
    private int numberOfButtons;
    private static final int MAX_BUTTONS = 20;
    private Button[] buttons = new Button[MAX_BUTTONS];
    private TextArea textArea = new TextArea();
    private GridPane wordButtonsPane = new GridPane();
    private VBox allPanes = new VBox();
    private TextField wordField = new TextField();
    private Button createWordButton = new Button("Create Word");

    /**
     * Creates the entire GUI except for the dynamic buttons.
     * 
     */
    @Override
    public void start(Stage primaryStage) throws Exception {
        allPanes.getChildren().add(textArea);
        allPanes.getChildren().add(wordButtonsPane);
        allPanes.getChildren().add(wordField);
        allPanes.getChildren().add(createWordButton);
        Scene scene = new Scene(allPanes);
        primaryStage.setTitle("Assignment 2");
        primaryStage.setScene(scene);
        primaryStage.show();
        createWordButton.setOnAction(this);
    }

    /**
     * Launches the application.
     * 
     * @param args
     *            not used
     */
    public static void main(String[] args) {
        Application.launch(null);
    }

    /**
     * If the createWordButton is clicked, a new button is created to represent
     * the text in the textfield. That is done, provided the maximum limit is
     * not reached. If one of the dynamically created buttons is clicked, the
     * corresponding text is appended to the textarea.
     * 
     */
    @Override
    public void handle(ActionEvent event) {
        if (event.getSource().equals(createWordButton)) {
            if (numberOfButtons < MAX_BUTTONS) {
                buttons[numberOfButtons] = new Button(wordField.getText());
                buttons[numberOfButtons].setOnAction(this);
                wordButtonsPane.add(buttons[numberOfButtons], numberOfButtons % 4, numberOfButtons / 4);
                numberOfButtons++;
            }
        } else {
            String text = ((Button) event.getSource()).getText();
            textArea.appendText(text);
        }
    }
}