package commands;

import shapes.Shape;
import states.DrawingContext;
import states.DrawingState;

/**
 *
 *            Redistribution and use with or without modification, are permitted
 *            provided that the following conditions are met:
 *
 *            - the use is for academic purpose only - Redistributions of source
 *            code must retain the above copyright notice, this list of
 *            conditions and the following disclaimer. - The name of Brahma Dathan may not be used to endorse or promote
 *            products derived from this software without specific prior written
 *            permission.
 *
 *            The author does not make any claims regarding the correctness of
 *            the code in this module and are not responsible for any loss or
 *            damage resulting from its use.
 */
/**
 * For grouping shapes
 *
 * @author Brahma Dathan
 */
public class GroupCommand extends Command {
    private Shape shape;

    /**
     * Creates a Group command.
     *
     * @param shape
     *            the shape that is a composite
     */
    public GroupCommand(Shape shape) {
        this.shape = shape;
    }

    /**
     * Executes the command by setting the color to red
     */
    @Override
    public void execute() {
        shape.setColor(255, 0, 0);
        DrawingContext.instance().setShape(shape);
    }

    /**
     * Undoes the command by resetting the color to blue
     */
    @Override
    public boolean undo() {
        shape.setColor(0, 0, 255);
        return super.undo();
    }

    /**
     * Recreates the group by calling execute
     */
    @Override
    public boolean redo() {
        shape.setColor(0, 0, 255);
        execute();
        return super.redo();
    }

    @Override
    public void end(DrawingState beforeState, DrawingState afterState) {
        shape.setColor(0, 0, 255);
        super.end(beforeState, afterState);
    }

    public Shape getShape() {
        return shape;
    }

    @Override
    public String toString() {
        return "GroupCommand [shape=" + shape + "]";
    }
}
