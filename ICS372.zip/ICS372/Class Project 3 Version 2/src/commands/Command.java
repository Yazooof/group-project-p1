package commands;

import states.DrawingContext;
import states.DrawingState;

/**
 *
 *            Redistribution and use with or without modification, are permitted
 *            provided that the following conditions are met:
 *
 *            - the use is for academic purpose only - Redistributions of source
 *            code must retain the above copyright notice, this list of
 *            conditions and the following disclaimer. - The name of Brahma Dathan may not be used to endorse or promote
 *            products derived from this software without specific prior written
 *            permission.
 *
 *            The author does not make any claims regarding the correctness of
 *            the code in this module and are not responsible for any loss or
 *            damage resulting from its use.
 */
/**
 * The Command class implements the Command pattern.
 *
 * @author Brahma Dathan
 */
public abstract class Command {
    private DrawingState stateBeforeCommand;
    private DrawingState stateAfterCommand;

    /**
     * Undoes the command
     *
     * @return true iff the operation is successful
     */
    public boolean undo() {
        DrawingContext.instance().changeCurrentState(stateBeforeCommand);
        return true;
    }

    /**
     * Redoes the command.
     *
     * @return true iff the operation is successful
     */
    public boolean redo() {
        DrawingContext.instance().changeCurrentState(stateAfterCommand);
        return true;
    }

    /**
     * Executes command.
     */
    public abstract void execute();

    /**
     * The default end of a command
     */
    public void end(DrawingState beforeState, DrawingState afterState) {
        this.stateBeforeCommand = beforeState;
        this.stateAfterCommand = afterState;
    }

    public DrawingState getStateAfterCommand() {
        return stateAfterCommand;
    }

    public DrawingState getStateBeforeCommand() {
        return stateBeforeCommand;
    }

    public void setStateAfterCommand(DrawingState stateAfterCommand) {
        this.stateAfterCommand = stateAfterCommand;
    }
}
