package commands;

import java.util.Iterator;

import model.Model;
import shapes.Shape;
import states.DrawingState;

/**
 *
 *            Redistribution and use with or without modification, are permitted
 *            provided that the following conditions are met:
 *
 *            - the use is for academic purpose only - Redistributions of source
 *            code must retain the above copyright notice, this list of
 *            conditions and the following disclaimer. - The name of Brahma Dathan may not be used to endorse or promote
 *            products derived from this software without specific prior written
 *            permission.
 *
 *            The author does not make any claims regarding the correctness of
 *            the code in this module and are not responsible for any loss or
 *            damage resulting from its use.
 */
/**
 * For ungrouping shapes
 *
 * @author Brahma Dathan
 */
public class UnGroupCommand extends Command {
    private Shape compositeShape;

    /**
     * Creates a UnGroup command.
     *
     * @param shape
     *            the shape that is a composite
     */
    public UnGroupCommand(Shape shape) {
        this.compositeShape = shape;
    }

    /**
     * Executes the command
     */
    @Override
    public void execute() {
        for (Iterator<Shape> iterator = compositeShape.getShapes(); iterator != null && iterator.hasNext();) {
            Shape shape = iterator.next();
            shape.setColor(0, 0, 255);
            Model.instance().addShape(shape);
        }
        Model.instance().removeShape(compositeShape);
    }

    /**
     * Undoes the command by resetting the color to blue
     */
    @Override
    public boolean undo() {
        Model.instance().addShape(compositeShape);
        for (Iterator<Shape> iterator = compositeShape.getShapes(); iterator != null && iterator.hasNext();) {
            Shape shape = iterator.next();
            Model.instance().removeShape(shape);
        }
        return super.undo();
    }

    /**
     * Recreates the group by calling execute
     */
    @Override
    public boolean redo() {
        execute();
        return super.redo();
    }

    @Override
    public void end(DrawingState beforeState, DrawingState afterState) {
        super.end(beforeState, afterState);
    }

    public Shape getShape() {
        return compositeShape;
    }

    @Override
    public String toString() {
        return "UnGroupCommand ";
    }
}
