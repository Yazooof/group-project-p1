package commands;

import javafx.geometry.Point2D;
import model.Model;
import shapes.Label;

/**
 * 
 *            Redistribution and use with or without modification, are permitted
 *            provided that the following conditions are met:
 *
 *            - the use is for academic purpose only - Redistributions of source
 *            code must retain the above copyright notice, this list of
 *            conditions and the following disclaimer. - The name of Brahma Dathan may not be used to endorse or promote
 *            products derived from this software without specific prior written
 *            permission.
 *
 *            The author does not make any claims regarding the correctness of
 *            the code in this module and are not responsible for any loss or
 *            damage resulting from its use.
 */
/**
 * Implements the Label command, so label creations can be undone. *
 * 
 * @author Brahma Dathan
 */
public class LabelCommand extends Command {
    private Label label;

    /**
     * Creates the label
     * 
     * @param point
     *            starting point
     */
    public LabelCommand(Point2D point) {
        label = new Label(point);
    }

    /**
     * Adds a piece of text to the label
     * 
     * @param String
     *            the text to be added
     */
    public void addCharacter(String character) {
        label.addCharacter(character);
        Model.instance().updateView();
    }

    /**
     * Removes the last character from the label
     */
    public void removeCharacter() {
        label.removeCharacter();
        Model.instance().updateView();
    }

    /**
     * Executes the command, essentially by supplying it to the model.
     */
    @Override
    public void execute() {
        Model.instance().addShape(label);
    }

    /**
     * Removes the label
     */
    @Override
    public boolean undo() {
        Model.instance().removeShape(label);
        return super.undo();
    }

    /**
     * Re-creates the label by supplying it to the model
     */
    @Override
    public boolean redo() {
        execute();
        return super.redo();
    }

    @Override
    public String toString() {
        return "LabelCommand [label=" + label + "]";
    }
}
