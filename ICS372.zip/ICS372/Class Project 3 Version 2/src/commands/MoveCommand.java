package commands;

import javafx.geometry.Point2D;
import model.Model;
import shapes.Shape;
import states.DrawingState;

/**
 *
 *            Redistribution and use with or without modification, are permitted
 *            provided that the following conditions are met:
 *
 *            - the use is for academic purpose only - Redistributions of source
 *            code must retain the above copyright notice, this list of
 *            conditions and the following disclaimer. - The name of Brahma Dathan may not be used to endorse or promote
 *            products derived from this software without specific prior written
 *            permission.
 *
 *            The author does not make any claims regarding the correctness of
 *            the code in this module and are not responsible for any loss or
 *            damage resulting from its use.
 */
/**
 * For selecting shapes
 *
 * @author Brahma Dathan
 */
public class MoveCommand extends Command {
    private Shape originalShape;
    private Shape newShape;

    /**
     * Creates a select command.
     *
     * @param point
     *            one of the points
     */
    public MoveCommand(Shape shape, int x, int y) {
        this.originalShape = shape;
        this.newShape = (Shape) shape.clone();
        originalShape.setColor(255, 0, 0);
        newShape.setColor(220, 220, 220);
        moveShape(x, y);
    }

    /**
     * Moves the shape based on a new clicked location
     * 
     * @param x
     *            the location's x coordinate
     * @param y
     *            the location's y coordinate
     */
    public void moveShape(int x, int y) {
        Point2D offset = newShape.getBoundingCorner();
        int xOffset = x - (int) offset.getX();
        int yOffset = y - (int) offset.getY();
        newShape.move(xOffset, yOffset);
    }

    public Shape getShape() {
        return newShape;
    }

    /**
     * Executes the command by setting the color to red
     */
    @Override
    public void execute() {
        newShape.setColor(220, 220, 220);
        Model.instance().addShape(newShape);
    }

    @Override
    public void end(DrawingState beforeState, DrawingState afterState) {
        super.end(beforeState, afterState);
        Model.instance().removeShape(originalShape);
        newShape.setColor(0, 0, 255);
    }

    /**
     * Undoes the command by resetting the color to blue
     */
    @Override
    public boolean undo() {
        Model.instance().removeShape(newShape);
        Model.instance().addShape(originalShape);
        return super.undo();
    }

    /**
     * Brings the line back by calling execute
     */
    @Override
    public boolean redo() {
        Model.instance().removeShape(originalShape);
        Model.instance().addShape(newShape);
        return super.redo();
    }

    @Override
    public String toString() {
        return "MoveCommand [originalShape=" + originalShape + ", newShape=" + newShape + "]";
    }
}
