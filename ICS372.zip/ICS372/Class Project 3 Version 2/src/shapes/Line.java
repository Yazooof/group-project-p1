package shapes;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import javafx.geometry.Point2D;
import renderer.Renderer;

/**
 * 
 * @author Brahma Dathan and Sarnath Ramnath
 * @Copyright (c) 2010
 
 * Redistribution and use with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *   - the use is for academic purpose only
 *   - Redistributions of source code must retain the above copyright
 *     notice, this list of conditions and the following disclaimer.
 *   - Neither the name of Brahma Dathan or Sarnath Ramnath
 *     may be used to endorse or promote products derived
 *     from this software without specific prior written permission.
 *
 * The authors do not make any claims regarding the correctness of the code in this module
 * and are not responsible for any loss or damage resulting from its use.  
 */

/**
 * Represents a line
 *
 */
public class Line extends Shape {
    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    private transient Point2D point1;
    private transient Point2D point2;

    /**
     * Creates a line with the given endpoints
     * 
     * @param point1
     *            one endpoint
     * @param point2
     *            another endpoint
     */
    public Line(Point2D point1) {
        this.point1 = point1;
        this.point2 = point1;
    }

    /**
     * Creates a line with no specific end points
     */
    public Line() {
    }

    /**
     * Checks whether the given Point2D falls within the line
     * 
     * @return true iff the given Point2D is close to one of the endpoints
     */
    @Override
    public boolean includes(Point2D point) {
        return ((distance(point, point1) < 10.0) || (distance(point, point2) < 10.0));
    }

    /**
     * Displays the line
     */
    @Override
    public void render(Renderer renderer) {
        super.render(renderer);
        renderer.draw(point1.getX(), point1.getY(), point2.getX(), point2.getY());
    }

    /**
     * Sets one of the endpoints
     * 
     * @param point
     *            an endpoint
     */

    public void setPoint2(Point2D point) {
        point2 = point;
    }

    /**
     * Returns one of the endpoints
     * 
     * @return an endpoint
     */
    public Point2D getPoint1() {
        return point1;
    }

    /**
     * Returns one of the endpoints
     * 
     * @return an endpoint
     */
    public Point2D getPoint2() {
        return point2;
    }

    /**
     * Deserializes the line
     * 
     * @param ois
     *            the object input stream
     * @throws IOException
     * @throws ClassNotFoundException
     */
    private void readObject(ObjectInputStream ois) throws IOException, ClassNotFoundException {
        ois.defaultReadObject();
        double x1 = ois.readDouble();
        double y1 = ois.readDouble();
        point1 = new Point2D(x1, y1);
        double x2 = ois.readDouble();
        double y2 = ois.readDouble();
        point2 = new Point2D(x2, y2);
    }

    /**
     * Serializes the line
     * 
     * @param oos
     *            object output stream
     * @throws IOException
     */
    private void writeObject(ObjectOutputStream oos) throws IOException {
        oos.defaultWriteObject();
        oos.writeDouble(point1.getX());
        oos.writeDouble(point1.getY());
        oos.writeDouble(point2.getX());
        oos.writeDouble(point2.getY());
    }

    @Override
    public String toString() {
        return "Line [point1=" + point1 + ", point2=" + point2 + "]\n" + " red " + red + " green " + green + " blue"
                + blue;
    }

    @Override
    public void move(int xOffset, int yOffset) {
        point1 = point1.add(xOffset, yOffset);
        point2 = point2.add(xOffset, yOffset);
    }

    @Override
    public Point2D getBoundingCorner() {
        return new Point2D((int) Math.min(point1.getX(), point2.getX()), (int) Math.min(point1.getY(), point2.getY()));
    }

    @Override
    public Object clone() {
        Line cloned = null;
        cloned = (Line) super.clone();
        return cloned;
    }
}