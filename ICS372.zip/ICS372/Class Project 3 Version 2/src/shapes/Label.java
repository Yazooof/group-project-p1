package shapes;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import javafx.geometry.Point2D;
import renderer.Renderer;

/**
 * 
 * @author Brahma Dathan and Sarnath Ramnath
 * @Copyright (c) 2010
 
 * Redistribution and use with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *   - the use is for academic purpose only
 *   - Redistributions of source code must retain the above copyright
 *     notice, this list of conditions and the following disclaimer.
 *   - Neither the name of Brahma Dathan or Sarnath Ramnath
 *     may be used to endorse or promote products derived
 *     from this software without specific prior written permission.
 *
 * The authors do not make any claims regarding the correctness of the code in this module
 * and are not responsible for any loss or damage resulting from its use.  
 */

/**
 * Implements a label; stores the end points and text.
 *
 */
public class Label extends Shape {
    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    private transient Point2D startingPoint;
    private String text = "";

    /**
     * Creates a label object with the starting point determined.
     * 
     * @param point
     *            the start of the label
     */
    public Label(Point2D point) {
        startingPoint = point;
    }

    /**
     * Adds one more character to the label
     * 
     * @param character
     *            a new character in the label
     */
    public void addCharacter(String character) {
        text += character;
    }

    /**
     * removes the rightmost character in the label
     */
    public void removeCharacter() {
        if (text.length() > 0) {
            text = text.substring(0, text.length() - 1);
        }
    }

    /**
     * Checks if the given point is in the label
     */
    @Override
    public boolean includes(Point2D point) {
        return distance(point, startingPoint) < 10.0;
    }

    /**
     * Displays the label
     */
    @Override
    public void render(Renderer renderer) {
        super.render(renderer);
        renderer.draw((int) startingPoint.getX(), (int) startingPoint.getY(), text);
    }

    /**
     * Returns the actual text in the label
     * 
     * @return the text in the label
     */
    public String getText() {
        return text;
    }

    /**
     * Returns the starting point
     * 
     * @return starting point
     */
    public Point2D getStartingPoint() {
        return startingPoint;
    }

    /**
     * Deserializes the label
     * 
     * @param ois
     *            the object input stream
     * @throws IOException
     * @throws ClassNotFoundException
     */
    private void readObject(ObjectInputStream ois) throws IOException, ClassNotFoundException {
        ois.defaultReadObject();
        double x = ois.readDouble();
        double y = ois.readDouble();
        startingPoint = new Point2D(x, y);
    }

    /**
     * Serializes the label
     * 
     * @param oos
     *            object output stream
     * @throws IOException
     */
    private void writeObject(ObjectOutputStream oos) throws IOException {
        oos.defaultWriteObject();
        oos.writeDouble(startingPoint.getX());
        oos.writeDouble(startingPoint.getY());
    }

    @Override
    public void move(int xOffset, int yOffset) {
        Point2D offset = new Point2D(xOffset, yOffset);
        startingPoint = startingPoint.add(offset);
    }

    @Override
    public Point2D getBoundingCorner() {
        return startingPoint;
    }

    @Override
    public Object clone() {
        Label cloned = null;
        cloned = (Label) super.clone();
        cloned.startingPoint = new Point2D(startingPoint.getX(), startingPoint.getY());
        return cloned;
    }

    @Override
    public String toString() {
        return "Label [startingPoint=" + startingPoint + ", text=" + text + "]";
    }

}