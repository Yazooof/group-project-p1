package shapes;

/**
 * 
 * @author Brahma Dathan
 * @Copyright (c) 2018
 
 * Redistribution and use with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *   - the use is for academic purpose only
 *   - Redistributions of source code must retain the above copyright
 *     notice, this list of conditions and the following disclaimer.
 *   - Neither the name of Brahma Dathan or Sarnath Ramnath
 *     may be used to endorse or promote products derived
 *     from this software without specific prior written permission.
 *
 * The authors do not make any claims regarding the correctness of the code in this module
 * and are not responsible for any loss or damage resulting from its use.  
 */

import java.io.Serializable;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

import javafx.geometry.Point2D;
import renderer.Renderer;

/**
 * Superclass for composites of drawable objects.
 *
 */
public class CompositeShape extends Shape implements Serializable, Cloneable {
    private static final long serialVersionUID = 1L;

    private List<Shape> shapes = new LinkedList<Shape>();

    @Override
    public boolean includes(Point2D point) {
        for (Shape shape : shapes) {
            if (shape.includes(point)) {
                return true;
            }
        }
        return false;
    }

    @Override
    public void setColor(int red, int green, int blue) {
        for (Shape shape : shapes) {
            shape.setColor(red, green, blue);
        }
    }

    @Override
    public boolean addShape(Shape shape) {
        if (this != shape && !this.shapes.contains(shape)) {
            shapes.add(shape);
            shape.setColor(255, 0, 0);
            return true;
        }
        return false;
    }

    @Override
    public void removeShape(Shape shape) {
        shapes.remove(shape);
    }

    @Override
    public Iterator<Shape> getShapes() {
        return shapes.iterator();
    }

    @Override
    public Point2D getBoundingCorner() {
        Point2D first = shapes.get(0).getBoundingCorner();
        int xLeft = (int) first.getX();
        int yTop = (int) first.getY();
        for (Shape shape : shapes) {
            Point2D bound = shape.getBoundingCorner();
            if (xLeft < ((int) bound.getX())) {
                xLeft = (int) bound.getX();
            }
            if (yTop < ((int) bound.getY())) {
                yTop = (int) bound.getY();
            }
        }
        return new Point2D(xLeft, yTop);
    }

    /**
     * Draw the figure on the UI
     */
    public void render(Renderer renderer) {
        for (Shape shape : shapes) {
            shape.render(renderer);
        }
    }

    @Override
    public void move(int x, int y) {
        for (Shape shape : shapes) {
            shape.move(x, y);
        }
    }

    /*
     * The clone() method does not seem to work properly, unless the shape is
     * explicitly created.
     */
    @Override
    public Object clone() {
        CompositeShape cloned = new CompositeShape();
        try {
            for (Shape shape : shapes) {
                cloned.shapes.add((Shape) shape.clone());
            }
        } finally {
            return cloned;
        }
    }

    @Override
    public String toString() {
        return "CompositeShape " + shapes;
    }
}