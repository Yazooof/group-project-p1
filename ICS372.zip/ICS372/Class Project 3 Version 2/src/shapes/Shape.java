package shapes;

/**
 * 
 * @author Brahma Dathan and Sarnath Ramnath
 * @Copyright (c) 2010
 
 * Redistribution and use with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *   - the use is for academic purpose only
 *   - Redistributions of source code must retain the above copyright
 *     notice, this list of conditions and the following disclaimer.
 *   - Neither the name of Brahma Dathan or Sarnath Ramnath
 *     may be used to endorse or promote products derived
 *     from this software without specific prior written permission.
 *
 * The authors do not make any claims regarding the correctness of the code in this module
 * and are not responsible for any loss or damage resulting from its use.  
 */

import java.io.Serializable;
import java.util.Iterator;

import javafx.geometry.Point2D;
import renderer.Renderer;

/**
 * Superclass for all types of drawable objects.
 *
 */
public abstract class Shape implements Serializable, Cloneable {
    private static final long serialVersionUID = 1L;

    protected int red = 0;
    protected int green = 0;
    protected int blue = 255;

    /**
     * Checks whether a point falls within the figure.
     * 
     * @param point
     *            the point
     * @return true iff the point is in the figure
     */
    public abstract boolean includes(Point2D point);

    /**
     * Calculates the distance between two points
     * 
     * @param point1
     *            one of the two points
     * @param point2
     *            one of the two points
     * @return distance between the points
     */
    protected double distance(Point2D point1, Point2D point2) {
        double xDifference = point1.getX() - point2.getX();
        double yDifference = point1.getY() - point2.getY();
        return ((Math.sqrt(xDifference * xDifference + yDifference * yDifference)));
    }

    /**
     * Gets the top left corner of the bounding rectangle of the shape.
     * 
     * @return the top left corner of the bounding rectangle of the shape.
     * 
     */
    public abstract Point2D getBoundingCorner();

    /**
     * Draw the figure on the UI
     */
    public void render(Renderer renderer) {
        renderer.setColor(red, green, blue);
        renderer.draw();
    }

    /**
     * Moves the shape to a new area whose top-left coordinates are given by x
     * and y
     * 
     * @param x
     *            x-coordinate of the top left point of the bounding rectangle
     *            of the destination
     * @param y
     *            y-coordinate of the top left point of the bounding rectangle
     *            of the destination
     */
    public abstract void move(int x, int y);

    /**
     * Sets the rendering color
     * 
     * @param red
     *            red value 0-255
     * @param green
     *            value 0-255
     * @param blue
     *            value 0-255
     */
    public void setColor(int red, int green, int blue) {
        this.red = red;
        this.green = green;
        this.blue = blue;
    }

    /**
     * Adds a shape for implementing the composite pattern.
     * 
     * @param shape
     *            the Shape to be added
     */
    public boolean addShape(Shape shape) {
        return false;
    }

    /**
     * Removes a shape for implementing the composite pattern.
     * 
     * @param shape
     *            the Shape to be removed
     */
    public void removeShape(Shape shape) {
    }

    @Override
    public Object clone() {
        Shape cloned = null;
        try {
            cloned = (Shape) super.clone();
        } catch (CloneNotSupportedException cnse) {

        } finally {
            return cloned;
        }
    }

    public int getRed() {
        return red;
    }

    public int getGreen() {
        return green;
    }

    public int getBlue() {
        return blue;
    }

    @Override
    public String toString() {
        return "Shape [red=" + red + ", green=" + green + ", blue=" + blue + "]";
    }

    public Iterator<Shape> getShapes() {
        return null;
    }
}