/**
 * 
 * @author Brahma Dathan
 * @Copyright (c) 2018
 
 * Redistribution and use with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *   - the use is for academic purpose only
 *   - Redistributions of source code must retain the above copyright
 *     notice, this list of conditions and the following disclaimer.
 *   - Neither the name of Brahma Dathan or Sarnath Ramnath
 *     may be used to endorse or promote products derived
 *     from this software without specific prior written permission.
 *
 * The authors do not make any claims regarding the correctness of the code in this module
 * and are not responsible for any loss or damage resulting from its use.  
 */
package shapes;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Arrays;

import javafx.geometry.Point2D;
import renderer.Renderer;

public class Polygon extends Shape {
    /**
     * 
     */
    private static final long serialVersionUID = 1L;
    private transient Point2D[] points;
    private int numberOfPoints;

    /**
     * Creates the polygon with the starting vertex. The vertices are stored in
     * an array. If needed, the array is expanded.
     * 
     * @param point
     *            the first vertex
     */
    public Polygon(Point2D point) {
        points = new Point2D[10];
        points[0] = point;
        numberOfPoints = 1;
    }

    /**
     * Adds one more vertex to the polygon
     * 
     * @param point
     */
    public void addPoint(Point2D point) {
        if (this.points.length == numberOfPoints) {
            Point2D[] temp = new Point2D[numberOfPoints * 2];
            System.arraycopy(points, 0, temp, 0, numberOfPoints);
            points = temp;
        }
        points[numberOfPoints++] = point;
    }

    /**
     * Adds the first vertex as the last vertex, so the drawing would be
     * complete.
     */
    public void end() {
        addPoint(points[0]);
    }

    @Override
    public boolean includes(Point2D point) {
        for (int index = 0; index < numberOfPoints - 1; index++) {
            Point2D thisVertex = points[index];
            if (thisVertex.distance(point) < 10) {
                return true;
            }
        }
        return false;
    }

    @Override
    public void render(Renderer renderer) {
        super.render(renderer);
        for (int index = 0; index < numberOfPoints - 1; index++) {
            renderer.draw(points[index].getX(), points[index].getY(), points[index + 1].getX(),
                    points[index + 1].getY());
        }
    }

    /**
     * Deserializes the polygon
     * 
     * @param ois
     *            the object input stream
     * @throws IOException
     * @throws ClassNotFoundException
     */
    private void readObject(ObjectInputStream ois) throws IOException, ClassNotFoundException {
        ois.defaultReadObject();
        double[] x = (double[]) ois.readObject();
        double[] y = (double[]) ois.readObject();
        points = new Point2D[numberOfPoints];
        for (int index = 0; index < numberOfPoints; index++) {
            points[index] = new Point2D(x[index], y[index]);
        }
    }

    /**
     * Serializes the polygon
     * 
     * @param oos
     *            object output stream
     * @throws IOException
     */
    private void writeObject(ObjectOutputStream oos) throws IOException {
        oos.defaultWriteObject();
        double[] x = new double[numberOfPoints];
        double[] y = new double[numberOfPoints];
        for (int index = 0; index < numberOfPoints; index++) {
            x[index] = points[index].getX();
            y[index] = points[index].getY();
        }
        oos.writeObject(x);
        oos.writeObject(y);
    }

    @Override
    public void move(int xOffset, int yOffset) {
        Point2D offset = new Point2D(xOffset, yOffset);
        for (int index = 0; index < numberOfPoints; index++) {
            points[index] = points[index].add(offset);
        }
        points[numberOfPoints] = points[0];
    }

    @Override
    public Point2D getBoundingCorner() {
        int xLeft = (int) points[0].getX();
        int yTop = (int) points[0].getY();
        for (int index = 0; index < numberOfPoints - 1; index++) {
            Point2D point = points[index];
            if (((int) point.getX()) < xLeft) {
                xLeft = (int) points[index].getX();
            }
            if (((int) point.getY()) < yTop) {
                yTop = (int) points[index].getY();
            }
        }
        return new Point2D(xLeft, yTop);
    }

    @Override
    public Object clone() {
        Polygon cloned = null;
        cloned = (Polygon) super.clone();
        cloned.points = new Point2D[points.length + 1];
        for (int index = 0; index < numberOfPoints; index++) {
            cloned.points[index] = new Point2D(points[index].getX(), points[index].getY());
        }
        return cloned;
    }

    @Override
    public String toString() {
        return "Polygon [points=" + Arrays.toString(points) + ", numberOfPoints=" + numberOfPoints + "]";
    }
}
