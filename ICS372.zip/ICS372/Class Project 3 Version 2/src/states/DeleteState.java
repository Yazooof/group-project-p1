/**
 *
 *            Redistribution and use with or without modification, are permitted
 *            provided that the following conditions are met:
 *
 *            - the use is for academic purpose only - Redistributions of source
 *            code must retain the above copyright notice, this list of
 *            conditions and the following disclaimer. - The name of Brahma Dathan
 *            may not be used to endorse or promote
 *            products derived from this software without specific prior written
 *            permission.
 *
 *            The author does not make any claims regarding the correctness of
 *            the code in this module and are not responsible for any loss or
 *            damage resulting from its use.
 */
package states;

import commands.CommandManager;
import commands.DeleteCommand;
import events.EnterKeyEvent;
import view.LogicalViewImpl;

/**
 * Shape delete event.
 *
 * @author Brahma Dathan
 *
 */
public class DeleteState extends DrawingState {
    private static DeleteState instance;

    /**
     * Private constructor to make the class a singleton
     */
    private DeleteState() {

    }

    /**
     * Returns the singleton object
     *
     * @return - the only instance of the class
     */
    public static DeleteState instance() {
        if (instance == null) {
            instance = new DeleteState();
        }
        return instance;
    }

    @Override
    public void enter() {
        LogicalViewImpl.instance().setsCursorToDrawing();
    }

    @Override
    public void leave() {
        LogicalViewImpl.instance().setCursorToDefault();
    }

    @Override
    public void abandon() {
        DrawingContext.instance().changeCurrentState(SelectSecondState.instance());
    }

    @Override
    public void handleEvent(EnterKeyEvent event) {
        CommandManager.instance().beginCommand(new DeleteCommand(DrawingContext.instance().getShape()));
        CommandManager.instance().endCommand(SelectSecondState.instance(), QuiescentState.instance());
        LogicalViewImpl.instance().update();
        DrawingContext.instance().changeCurrentState(QuiescentState.instance());
    }
}
