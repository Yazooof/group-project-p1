/**
 *
 *            Redistribution and use with or without modification, are permitted
 *            provided that the following conditions are met:
 *
 *            - the use is for academic purpose only - Redistributions of source
 *            code must retain the above copyright notice, this list of
 *            conditions and the following disclaimer. - The name of Brahma Dathan
 *            may not be used to endorse or promote
 *            products derived from this software without specific prior written
 *            permission.
 *
 *            The author does not make any claims regarding the correctness of
 *            the code in this module and are not responsible for any loss or
 *            damage resulting from its use.
 */
package states;

import java.util.Iterator;

import commands.CommandManager;
import commands.GroupCommand;
import events.ControlMouseClickEvent;
import events.EnterKeyEvent;
import model.Model;
import shapes.CompositeShape;
import shapes.Shape;
import view.LogicalViewImpl;

/**
 * Handles the input to move to delete or move a shape.
 *
 * @author Brahma Dathan
 *
 */
public class GroupSecondState extends DrawingState {
    private static GroupSecondState instance;

    /**
     * Private constructor to make the class a singleton
     */
    private GroupSecondState() {

    }

    /**
     * Returns the singleton object
     *
     * @return - the only instance of the class
     */
    public static GroupSecondState instance() {
        if (instance == null) {
            instance = new GroupSecondState();
        }
        return instance;
    }

    @Override
    public void enter() {
        LogicalViewImpl.instance().setsCursorToDrawing();
    }

    @Override
    public void leave() {
        LogicalViewImpl.instance().setCursorToDefault();
    }

    @Override
    public void abandon() {
        Shape compositeShape = ((GroupCommand) CommandManager.instance().getCommand()).getShape();
        for (Iterator<Shape> shapeIterator = compositeShape.getShapes(); shapeIterator.hasNext();) {
            Shape shape = shapeIterator.next();
            Model.instance().addShape(shape);
        }
        CommandManager.instance().undo();
        DrawingContext.instance().changeCurrentState(QuiescentState.instance());
    }

    @Override
    public void handleEvent(ControlMouseClickEvent event) {
        Shape shape = Model.instance().search(event.getX(), event.getY());
        if (shape != null) {
            if (((CompositeShape) ((GroupCommand) CommandManager.instance().getCommand()).getShape()).addShape(shape)) {
                Model.instance().removeShape(shape);
                LogicalViewImpl.instance().update();
            }
        }
    }

    @Override
    public void handleEvent(EnterKeyEvent event) {
        CommandManager.instance().endCommand(QuiescentState.instance(), QuiescentState.instance());
        DrawingContext.instance().changeCurrentState(QuiescentState.instance());
    }

    @Override
    public String toString() {
        return "GroupSecondState []";
    }
}
