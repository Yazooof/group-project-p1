/**
 *
 *            Redistribution and use with or without modification, are permitted
 *            provided that the following conditions are met:
 *
 *            - the use is for academic purpose only - Redistributions of source
 *            code must retain the above copyright notice, this list of
 *            conditions and the following disclaimer. - The name of Brahma Dathan
 *            may not be used to endorse or promote
 *            products derived from this software without specific prior written
 *            permission.
 *
 *            The author does not make any claims regarding the correctness of
 *            the code in this module and are not responsible for any loss or
 *            damage resulting from its use.
 */
package states;

import commands.CommandManager;
import commands.GroupCommand;
import events.ControlMouseClickEvent;
import model.Model;
import shapes.CompositeShape;
import shapes.Shape;
import view.LogicalViewImpl;

/**
 * Handles the click to group shapes.
 *
 * @author Brahma Dathan
 *
 */
public class GroupFirstState extends DrawingState {
    private static GroupFirstState instance;

    /**
     * Private constructor to make the class a singleton
     */
    private GroupFirstState() {

    }

    /**
     * Returns the singleton object
     *
     * @return - the only instance of the class
     */
    public static GroupFirstState instance() {
        if (instance == null) {
            instance = new GroupFirstState();
        }
        return instance;
    }

    @Override
    public void enter() {
        LogicalViewImpl.instance().setsCursorToDrawing();
    }

    @Override
    public void leave() {
        LogicalViewImpl.instance().setCursorToDefault();
    }

    @Override
    public void abandon() {
        DrawingContext.instance().changeCurrentState(QuiescentState.instance());
    }

    @Override
    public void handleEvent(ControlMouseClickEvent event) {
        Shape shape = Model.instance().search(event.getX(), event.getY());
        if (shape != null) {
            CompositeShape compositeShape = new CompositeShape();
            if (compositeShape.addShape(shape)) {
                CommandManager.instance().beginCommand(new GroupCommand(compositeShape));
                Model.instance().removeShape(shape);
                Model.instance().addShape(compositeShape);
                LogicalViewImpl.instance().update();
                DrawingContext.instance().changeCurrentState(GroupSecondState.instance());
            }
        } else {
            DrawingContext.instance().changeCurrentState(QuiescentState.instance());
        }
    }

}
