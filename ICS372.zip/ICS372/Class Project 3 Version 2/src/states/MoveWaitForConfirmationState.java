/**
 *
 *            Redistribution and use with or without modification, are permitted
 *            provided that the following conditions are met:
 *
 *            - the use is for academic purpose only - Redistributions of source
 *            code must retain the above copyright notice, this list of
 *            conditions and the following disclaimer. - The name of Brahma Dathan
 *            may not be used to endorse or promote
 *            products derived from this software without specific prior written
 *            permission.
 *
 *            The author does not make any claims regarding the correctness of
 *            the code in this module and are not responsible for any loss or
 *            damage resulting from its use.
 */
package states;

import commands.CommandManager;
import commands.MoveCommand;
import events.EnterKeyEvent;
import events.MouseClickEvent;
import view.LogicalViewImpl;

/**
 * Wait for confirmation to move or abandon.
 *
 * @author Brahma Dathan
 *
 */
public class MoveWaitForConfirmationState extends DrawingState {
    private static MoveWaitForConfirmationState instance;

    /**
     * Private constructor to make the class a singleton
     */
    private MoveWaitForConfirmationState() {

    }

    /**
     * Returns the singleton object
     *
     * @return - the only instance of the class
     */
    public static MoveWaitForConfirmationState instance() {
        if (instance == null) {
            instance = new MoveWaitForConfirmationState();
        }
        return instance;
    }

    @Override
    public void enter() {
        LogicalViewImpl.instance().setsCursorToDrawing();
    }

    @Override
    public void leave() {
        LogicalViewImpl.instance().setCursorToDefault();
    }

    @Override
    public void abandon() {
        CommandManager.instance().deletePartialCommand(SelectSecondState.instance(), QuiescentState.instance());
    }

    @Override
    public void handleEvent(EnterKeyEvent event) {
        CommandManager.instance().endCommand(SelectSecondState.instance(), QuiescentState.instance());
        LogicalViewImpl.instance().update();
        DrawingContext.instance().changeCurrentState(QuiescentState.instance());
    }

    @Override
    public void handleEvent(MouseClickEvent event) {
        ((MoveCommand) CommandManager.instance().getCommand()).moveShape(event.getX(), event.getY());
        LogicalViewImpl.instance().update();
    }
}
