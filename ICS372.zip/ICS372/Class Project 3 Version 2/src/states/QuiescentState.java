/**
 *
 *            Redistribution and use with or without modification, are permitted
 *            provided that the following conditions are met:
 *
 *            - the use is for academic purpose only - Redistributions of source
 *            code must retain the above copyright notice, this list of
 *            conditions and the following disclaimer. - The name of Brahma Dathan
 *            may not be used to endorse or promote
 *            products derived from this software without specific prior written
 *            permission.
 *
 *            The author does not make any claims regarding the correctness of
 *            the code in this module and are not responsible for any loss or
 *            damage resulting from its use.
 */
package states;

import events.ControlMouseClickEvent;
import events.CreateLabelEvent;
import events.CreateLineEvent;
import events.CreatePolygonEvent;
import events.MouseClickEvent;
import events.MouseEnterEvent;
import events.OpenRequestEvent;
import events.SaveRequestEvent;
import model.Model;
import view.LogicalViewImpl;

/**
 * Represents the state when no shape is being created.
 * 
 * @author Brahma Dathan
 *
 */
public class QuiescentState extends DrawingState {
    private static QuiescentState instance;

    /**
     * Private constructor to make the class a singleton
     */
    private QuiescentState() {

    }

    /**
     * Returns the singleton object
     *
     * @return - the only instance of the class
     */
    public static QuiescentState instance() {
        if (instance == null) {
            instance = new QuiescentState();
        }
        return instance;
    }

    @Override
    public void enter() {
        LogicalViewImpl.instance().setCursorToDefault();
    }

    @Override
    public void leave() {
        LogicalViewImpl.instance().setsCursorToDrawing();
    }

    @Override
    public void handleEvent(CreateLabelEvent event) {
        DrawingContext.instance().changeCurrentState(LabelFirstInputState.instance());
    }

    @Override
    public void handleEvent(CreateLineEvent event) {
        DrawingContext.instance().changeCurrentState(LineFirstInputState.instance());
    }

    @Override
    public void handleEvent(CreatePolygonEvent event) {
        DrawingContext.instance().changeCurrentState(PolygonFirstInputState.instance());
    }

    @Override
    public void handleEvent(OpenRequestEvent event) {
        Model.instance().retrieve(event.getFile());
    }

    @Override
    public void handleEvent(SaveRequestEvent event) {
        Model.instance().save(event.getFile());
    }

    @Override
    public void handleEvent(MouseEnterEvent event) {
        LogicalViewImpl.instance().setCursorToDefault();
    }

    /**
     * When the mouse click is received, the user is trying to select an item.
     * Change to that state and make the state handle the event.
     * 
     */
    @Override
    public void handleEvent(MouseClickEvent event) {
        DrawingContext.instance().changeCurrentState(SelectState.instance());
        DrawingContext.instance().handleEvent(event);
    }

    /**
     * When the mouse click is received with the control key down, the user is
     * trying to group items. Change to that state and make the state handle the
     * event.
     * 
     */
    @Override
    public void handleEvent(ControlMouseClickEvent event) {
        DrawingContext.instance().changeCurrentState(GroupFirstState.instance());
        DrawingContext.instance().handleEvent(event);
    }

    @Override
    public void abandon() {
    }
}
