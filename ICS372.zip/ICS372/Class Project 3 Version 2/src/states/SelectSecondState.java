/**
 *
 *            Redistribution and use with or without modification, are permitted
 *            provided that the following conditions are met:
 *
 *            - the use is for academic purpose only - Redistributions of source
 *            code must retain the above copyright notice, this list of
 *            conditions and the following disclaimer. - The name of Brahma Dathan
 *            may not be used to endorse or promote
 *            products derived from this software without specific prior written
 *            permission.
 *
 *            The author does not make any claims regarding the correctness of
 *            the code in this module and are not responsible for any loss or
 *            damage resulting from its use.
 */
package states;

import commands.CommandManager;
import commands.MoveCommand;
import commands.UnGroupCommand;
import events.DeleteKeyEvent;
import events.MouseClickEvent;
import events.ShiftEnterKeyEvent;
import shapes.Shape;
import view.LogicalViewImpl;

/**
 * Handles the input to move to delete, ungroup, or move a shape.
 *
 * @author Brahma Dathan
 *
 */
public class SelectSecondState extends DrawingState {
    private static SelectSecondState instance;

    /**
     * Private constructor to make the class a singleton
     */
    private SelectSecondState() {

    }

    /**
     * Returns the singleton object
     *
     * @return - the only instance of the class
     */
    public static SelectSecondState instance() {
        if (instance == null) {
            instance = new SelectSecondState();
        }
        return instance;
    }

    @Override
    public void enter() {
        LogicalViewImpl.instance().setsCursorToDrawing();
    }

    @Override
    public void leave() {
        LogicalViewImpl.instance().setCursorToDefault();
    }

    @Override
    public void abandon() {
        CommandManager.instance().undo();
        DrawingContext.instance().changeCurrentState(QuiescentState.instance());
    }

    @Override
    public void handleEvent(MouseClickEvent event) {
        Shape shape = DrawingContext.instance().getShape();
        CommandManager.instance().beginCommand(new MoveCommand(shape, event.getX(), event.getY()));
        DrawingContext.instance().changeCurrentState(MoveWaitForConfirmationState.instance());

    }

    @Override
    public void handleEvent(ShiftEnterKeyEvent event) {
        Shape shape = DrawingContext.instance().getShape();
        CommandManager.instance().beginCommand(new UnGroupCommand(shape));
        CommandManager.instance().endCommand(SelectState.instance(), QuiescentState.instance());
        DrawingContext.instance().changeCurrentState(QuiescentState.instance());
    }

    @Override
    public void handleEvent(DeleteKeyEvent event) {
        DrawingContext.instance().changeCurrentState(DeleteState.instance());
    }

    @Override
    public String toString() {
        return "SelectSecondState []";
    }
}
