/**
 *
 *            Redistribution and use with or without modification, are permitted
 *            provided that the following conditions are met:
 *
 *            - the use is for academic purpose only - Redistributions of source
 *            code must retain the above copyright notice, this list of
 *            conditions and the following disclaimer. - The name of Brahma Dathan
 *            may not be used to endorse or promote
 *            products derived from this software without specific prior written
 *            permission.
 *
 *            The author does not make any claims regarding the correctness of
 *            the code in this module and are not responsible for any loss or
 *            damage resulting from its use.
 */
package states;

import commands.CommandManager;
import commands.SelectCommand;
import events.MouseClickEvent;
import model.Model;
import shapes.Shape;
import view.LogicalViewImpl;

/**
 * Handles the click to select a shape.
 *
 * @author Brahma Dathan
 *
 */
public class SelectState extends DrawingState {
    private static SelectState instance;

    /**
     * Private constructor to make the class a singleton
     */
    private SelectState() {

    }

    /**
     * Returns the singleton object
     *
     * @return - the only instance of the class
     */
    public static SelectState instance() {
        if (instance == null) {
            instance = new SelectState();
        }
        return instance;
    }

    @Override
    public void enter() {
        LogicalViewImpl.instance().setsCursorToDrawing();
    }

    @Override
    public void leave() {
        LogicalViewImpl.instance().setCursorToDefault();
    }

    @Override
    public void abandon() {
        DrawingContext.instance().changeCurrentState(QuiescentState.instance());
    }

    @Override
    public void handleEvent(MouseClickEvent event) {
        Shape shape = Model.instance().search(event.getX(), event.getY());
        if (shape != null) {
            DrawingContext.instance().setShape(shape);
            CommandManager.instance().beginCommand(new SelectCommand(shape));
            CommandManager.instance().endCommand(QuiescentState.instance(), SelectSecondState.instance());
            LogicalViewImpl.instance().update();
            DrawingContext.instance().changeCurrentState(SelectSecondState.instance());
        } else {
            DrawingContext.instance().changeCurrentState(QuiescentState.instance());
        }
    }

}
