/**
 *
 *            Redistribution and use with or without modification, are permitted
 *            provided that the following conditions are met:
 *
 *            - the use is for academic purpose only - Redistributions of source
 *            code must retain the above copyright notice, this list of
 *            conditions and the following disclaimer. - The name of Brahma Dathan
 *            may not be used to endorse or promote
 *            products derived from this software without specific prior written
 *            permission.
 *
 *            The author does not make any claims regarding the correctness of
 *            the code in this module and are not responsible for any loss or
 *            damage resulting from its use.
 */
package states;

import commands.CommandManager;
import commands.PolygonCommand;
import events.MouseClickEvent;
import javafx.geometry.Point2D;
import view.LogicalViewImpl;

/**
 * Gets the third button click in the construction of a polygon.
 * 
 * @author Brahma Dathan
 *
 */
public class PolygonThirdInputState extends DrawingState {
    private static PolygonThirdInputState instance;

    /**
     * Private constructor to make the class a singleton
     */
    private PolygonThirdInputState() {

    }

    /**
     * Returns the singleton object
     *
     * @return - the only instance of the class
     */
    public static PolygonThirdInputState instance() {
        if (instance == null) {
            instance = new PolygonThirdInputState();
        }
        return instance;
    }

    @Override
    public void abandon() {
        CommandManager.instance().deletePartialCommand(QuiescentState.instance(), QuiescentState.instance());
        DrawingContext.instance().changeCurrentState(QuiescentState.instance());
    }

    @Override
    public void handleEvent(MouseClickEvent event) {
        PolygonCommand polygonCommand = (PolygonCommand) CommandManager.instance().getCommand();
        polygonCommand.addPoint(new Point2D(event.getX(), event.getY()));
        LogicalViewImpl.instance().update();
        DrawingContext.instance().changeCurrentState(PolygonSucceedingInputState.instance());
    }

    @Override
    public String toString() {
        return "PolygonThirdInputState []";
    }

}
