/**
 *
 *            Redistribution and use with or without modification, are permitted
 *            provided that the following conditions are met:
 *
 *            - the use is for academic purpose only - Redistributions of source
 *            code must retain the above copyright notice, this list of
 *            conditions and the following disclaimer. - The name of Brahma Dathan
 *            may not be used to endorse or promote
 *            products derived from this software without specific prior written
 *            permission.
 *
 *            The author does not make any claims regarding the correctness of
 *            the code in this module and are not responsible for any loss or
 *            damage resulting from its use.
 */
package states;

import commands.CommandManager;
import commands.LineCommand;
import events.MouseClickEvent;
import javafx.geometry.Point2D;

/**
 * Handles the first click for a line's end point
 * 
 * @author Brahma Dathan
 *
 */
public class LineFirstInputState extends DrawingState {
    private static LineFirstInputState instance;

    /**
     * Private constructor to make the class a singleton
     */
    private LineFirstInputState() {

    }

    /**
     * Returns the singleton object
     *
     * @return - the only instance of the class
     */
    public static LineFirstInputState instance() {
        if (instance == null) {
            instance = new LineFirstInputState();
        }
        return instance;
    }

    @Override
    public void abandon() {
        DrawingContext.instance().changeCurrentState(QuiescentState.instance());
    }

    @Override
    public void handleEvent(MouseClickEvent event) {
        CommandManager.instance().beginCommand(new LineCommand(new Point2D(event.getX(), event.getY())));
        DrawingContext.instance().changeCurrentState(LineSecondInputState.instance());
    }
}
