/**
 * 
 * @author Brahma Dathan
 * 
 *         Redistribution and use with or without modification, are permitted
 *         provided that the following conditions are met: the use is for
 *         academic purpose only - Redistributions of source code must retain
 *         the above copyright notice, this list of conditions and the following
 *         disclaimer. - The name of Brahma Dathan may not be used to
 *         endorse or promote products derived from this software without
 *         specific prior written permission.
 *
 *         The author does not make any claims regarding the correctness of the
 *         code in this module and are not responsible for any loss or damage
 *         resulting from its use.
 */
/**
 * The menu item for FX
 * 
 * @author Brahma Dathan
 *
 */
package drawingtool;

import events.MouseEnterEvent;
import events.MouseExitEvent;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.scene.Cursor;
import states.DrawingContext;
import view.FXPanel;
import view.PhysicalView;

/**
 * Sets up the area where the mouse clicks and keyboard events occur.
 *
 * @author Brahma Dathan
 *
 */
public class DrawingPanel extends FXPanel implements PhysicalView {
    /**
     * Sets up the listeners
     *
     * @param model
     */
    private Cursor drawingPanelCursor;

    public DrawingPanel() {
        setOnMouseEntered(new EventHandler() {
            @Override
            public void handle(Event me) {
                DrawingContext.instance().handleEvent(MouseEnterEvent.instance());
                setCursor(drawingPanelCursor); // Change cursor to crosshair
            }

        });
        setOnMouseExited(new EventHandler() {
            @Override
            public void handle(Event me) {
                DrawingContext.instance().handleEvent(MouseExitEvent.instance());
                setCursor(Cursor.DEFAULT); // Change cursor to crosshair
            }

        });
    }

    @Override
    public void setCursorToDefault() {
        drawingPanelCursor = Cursor.DEFAULT;
    }

    @Override
    public void setsCursorToDrawing() {
        drawingPanelCursor = Cursor.CROSSHAIR;
    }
}
