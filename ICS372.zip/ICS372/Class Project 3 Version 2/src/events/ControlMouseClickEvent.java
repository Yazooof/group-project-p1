/**
 * 
 *            Redistribution and use with or without modification, are permitted
 *            provided that the following conditions are met:
 *
 *            - the use is for academic purpose only - Redistributions of source
 *            code must retain the above copyright notice, this list of
 *            conditions and the following disclaimer. - The name of Brahma Dathan 
 *            may not be used to endorse or promote
 *            products derived from this software without specific prior written
 *            permission.
 *
 *            The author does not make any claims regarding the correctness of
 *            the code in this module and are not responsible for any loss or
 *            damage resulting from its use.
 */
package events;

/**
 * Represents an event of clicking the mouse with control pressed. This is a
 * singleton.
 * 
 * @author Brahma Dathan
 *
 */
public class ControlMouseClickEvent extends DrawingEvent {
    private static ControlMouseClickEvent instance;

    private int x;
    private int y;

    /**
     * The constructor stores the x and y coordinates.
     * 
     * @param x
     *            - the x coordinate
     * @param y
     *            - the y coordinate
     */
    public ControlMouseClickEvent(int x, int y) {
        this.x = x;
        this.y = y;
    }

    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }
}
