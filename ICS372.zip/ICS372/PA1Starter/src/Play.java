public class Play extends Event {

    /**
     * Creates a Play object with the description and price factor.
     * 
     * @param description
     *            the description of the play
     * @param priceFactor
     *            the price factor for the play
     */

    // TODO Create a constructor
	public Play(String description, double priceFactor) {
		super(description, priceFactor);
	}


    /**
     * Creates a play with the given description and a price factor of 1.0.
     * 
     * @param description
     *            the description of the play
     */

    // TODO Create a constructor
	public Play(String description) {
		super(description, 1.0);
		// TODO Auto-generated constructor stub
	}
    /**
     * Returns a String representation.
     * 
     */
    @Override
    public String toString() {
        return "Play " + super.toString()/* TODO */;
    }
}


